import socket

def send_command(command):
    # Specify the IP address of the ESP8266 and the port
    esp_ip = '192.168.4.1'  # Replace with your ESP8266's IP address
    esp_port = 1234  # Same port as the ESP8266 listens on

    # Create a UDP socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    
    try:
        # Send the command to the ESP8266
        sock.sendto(command.encode(), (esp_ip, esp_port))
        print(f"Sent: {command}")
    finally:
        sock.close()

# Example usage
send_command("M 4 2000")  # Replace this with the command you want to send
