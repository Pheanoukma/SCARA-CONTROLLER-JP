from rich.console import Console
from rich.prompt import Prompt
import serial
import socket  # For sending commands via UDP to ESP
import time  # Ensure time is imported for delays

console = Console()

banner = """
----------------------------------------------------
                SCARA CONTROLLER
                 V   . 1 . 0 . 2

Made by : Me (Pheanoukma)
----------------------------------------------------

Usages:

Running Command:

Ex.            M       1        2000
               (move) (joint)  (steps)

Change Values Command:

Ex.            S        1       3       2000
            (value)   (joint) (param)  (value)

List of Parameters:
1 = Set Speed
2 = Set Acceleration
3 = Max Speed

-----------------------------------------------------
"""

print(banner)

def select_com_port():
    console.print("Select the COM port for your Teensy (e.g., COM3):", style="bold green")
    while True:
        port = input("Enter COM port: ").strip()
        try:
            ser = serial.Serial(port, 115200, timeout=1)
            console.print(f"Connected to {port}", style="bold green")
            return ser
        except serial.SerialException:
            console.print(f"Could not open {port}. Please try again.", style="bold red")

def send_command(ser, command):
    try:
        ser.write(f"{command}\n".encode())
        console.print(f"Sent to Teensy: {command}", style="bold blue")
        time.sleep(0.1)  # Ensure small delay between commands
    except Exception as e:
        console.print(f"Failed to send command to Teensy: {e}", style="bold red")

def send_command_to_esp(command):
    esp_ip = "192.168.4.1"  # IP of the ESP8266
    esp_port = 1234  # Port the ESP8266 is listening on

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)  # Create UDP socket
    try:
        sock.sendto(command.encode(), (esp_ip, esp_port))
        console.print(f"Sent to ESP: {command}", style="bold blue")
    except Exception as e:
        console.print(f"Failed to send command to ESP: {e}", style="bold red")
    finally:
        sock.close()

def record_commands(ser):
    console.print("Recording commands. Type 'STOP' to end recording.", style="bold yellow")
    recorded_commands = []
    while True:
        command = input("Enter command: ").strip()
        if command.upper() == 'STOP':
            console.print("Stopped recording.", style="bold green")
            break
        recorded_commands.append(command)
        send_command(ser, command)
        send_command_to_esp(command)
    return recorded_commands

def playback_commands(ser, commands):
    console.print("Playing back recorded commands...", style="bold yellow")
    for command in commands:
        send_command(ser, command)
        send_command_to_esp(command)
        time.sleep(0.5)  # Optional delay between commands

def main():
    ser = select_com_port()
    recorded_commands = []

    try:
        while True:
            command = input("Enter command (M joint steps | H | R for record | P for playback | q to quit): ").strip()

            if command.lower() == 'q':
                console.print("Exiting...", style="bold red")
                break

            if command.upper() == 'R':
                recorded_commands = record_commands(ser)
                continue

            elif command.upper() == 'P':
                if recorded_commands:
                    playback_commands(ser, recorded_commands)
                else:
                    console.print("No commands recorded yet.", style="bold red")
                continue

            parts = command.split()
            console.print(f"Parsed command: {parts}", style="bold yellow")

            if len(parts) == 3 and parts[0] == 'M':
                try:
                    joint = int(parts[1])
                    steps = int(parts[2])
                    send_command(ser, f'M {joint} {steps}')
                    send_command_to_esp(f'M {joint} {steps}')
                except ValueError:
                    console.print("Invalid values for joint or steps.", style="bold red")

            elif len(parts) == 1 and parts[0] == 'H':
                send_command(ser, 'H')
                send_command_to_esp('H')

            elif len(parts) == 4 and parts[0] == 'S':
                try:
                    joint = int(parts[1])
                    param = int(parts[2])
                    value = int(parts[3])
                    send_command(ser, f'S {joint} {param} {value}')
                    send_command_to_esp(f'S {joint} {param} {value}')
                except ValueError:
                    console.print("Invalid values for joint, param, or value.", style="bold red")

            else:
                console.print("Invalid command. Use: M joint steps | H | R | P | q to quit", style="bold red")

    except Exception as e:
        console.print(f"An error occurred: {e}", style="bold red")

    finally:
        ser.close()
        console.print("Serial connection closed.", style="bold red")

if __name__ == "__main__":
    main()
