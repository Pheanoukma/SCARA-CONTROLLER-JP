# Define the path to your Python script
$scriptPath = "SCARA-CONTROLLER-V.1.0.2.py"  # Update with the full path to your Python script

# Run the Python script
python $scriptPath

# Optional: Add a message after the script execution
Write-Host "Script executed. Press Enter to exit..."
Read-Host