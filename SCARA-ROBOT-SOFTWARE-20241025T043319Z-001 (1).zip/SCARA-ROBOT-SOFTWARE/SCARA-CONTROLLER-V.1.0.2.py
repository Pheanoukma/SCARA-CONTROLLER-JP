import serial
import time
import sys

banner = """"
----------------------------------------------------
                SCARA CONTROLLER
                 V   . 1 . 0 .2

Made by : Me ( pheanoukma )
----------------------------------------------------
    
Usages :

Running Command : 

Ex.            M       1        2000
               ( move) (Joint ) (Steps)

Change values command

Ex.            S        1       3       2000
            (value)  (joint) (Param)  (VALUE)

List of Parameters :

1 = Set speed
2 = Set Acceleration
3 = Max Speed

-----------------------------------------------------


"""
print(banner)

def select_com_port():
    print("Select the COM port for your Teensy (e.g., COM3):")
    while True:
        port = input("Enter COM port: ").strip()
        try:
            ser = serial.Serial(port, 115200, timeout=1)
            print(f"Connected to {port}")
            return ser
        except serial.SerialException:
            print(f"Could not open {port}. Please try again.")

def send_command(ser, command):
    try:
        ser.write(f"{command}\n".encode())
        print(f"Sent: {command}")
        time.sleep(0.1)  # Delay to allow processing
    except Exception as e:
        print(f"Failed to send command: {e}")

def main():
    ser = select_com_port()  # Select COM port at runtime

    try:
        while True:
            command = input("Enter command (M joint steps | H | S joint param value | q to quit): ").strip()

            if command.lower() == 'q':
                print("Exiting...")
                break

            parts = command.split()
            if parts[0] == 'M' and len(parts) == 3:
                # Move command: M joint steps
                joint = int(parts[1])  # Joint number (1-4)
                steps = int(parts[2])   # Number of steps
                send_command(ser, f'M {joint} {steps}')

            elif parts[0] == 'H':
                # Home command
                send_command(ser, 'H')

            elif parts[0] == 'S' and len(parts) == 4:
                # Set parameter command: S joint param value
                joint = int(parts[1])  # Joint number (1-4)
                param = int(parts[2])  # Parameter type (1 = speed, 2 = acceleration, 3 = max speed)
                value = int(parts[3])  # New value
                send_command(ser, f'S {joint} {param} {value}')

            else:
                print("Invalid command. Use: M joint steps | H | S joint param value | q to quit")

    except Exception as e:
        print(f"An error occurred: {e}")

    finally:
        ser.close()
        print("Serial connection closed.")

if __name__ == "__main__":
    main()
